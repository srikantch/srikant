package com.action;

public interface Const 
{
	String url="https://cashkaro.iamsavings.co.uk/index.php";
	String username="srikant";
	String password="chinari";
	String Browser="firefox";
	int time=20;

}
